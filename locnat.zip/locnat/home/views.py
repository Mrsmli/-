from django.shortcuts import render
from django.views import View


class indexView(View):
    def get(self, request):
        return render(request,'index.html')
    def post(self, request):
        return render(request,'index.html')

class hederview(View):
    def get(self, request):
        return render(request,'shared/site_heder.html')
    def post(self, request):
        return render(request,'shared/site_heder.html')

class footerview(View):
    def get(self, request):
        return render(request,'shared/site_footer.html')
    def post(self, request):
        return render(request,'shared/site_footer.html')