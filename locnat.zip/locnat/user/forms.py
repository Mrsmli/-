from django import forms


class register_form (forms.Form):

    email = forms.EmailField(
        label='Email',
        widget=forms.EmailInput(attrs={
            'class': 'input100',
            'placeholder': 'Email',
            'name': 'email',
        })
    )
    username = forms.CharField(
        label='Username',
        widget=forms.TextInput(attrs={
            'class': 'input100',
            'placeholder': 'Username',

        })
    )
    password = forms.CharField(label='Password',
                                widget=forms.PasswordInput(attrs={
                                    'class': 'input100',
                                    'placeholder': 'Password',

                                })
    )


class login_form (forms.Form):

    username = forms.CharField(
        label='Username',
        widget=forms.TextInput(attrs={
            'class': 'input100',
            'placeholder': 'Username',

        })
    )
    password = forms.CharField(label='Password',
                                widget=forms.PasswordInput(attrs={
                                    'class': 'input100',
                                    'placeholder': 'Password',

                                })
    )

