from django.urls import path
from . import views

urlpatterns = [
    path('Register', views.Register_indexview.as_view(), name='Register'),
    path('login', views.login_indexview.as_view(), name='login'),

]

