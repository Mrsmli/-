import random

from django.contrib import messages
from django.contrib.auth import login
from django.http import HttpResponseRedirect, HttpRequest
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views import View

from user import forms
from .models import User


def generate_random_number():
    random_number = ''.join([str(random.randint(0, 9)) for _ in range(10)])
    return random_number


class Register_indexview(View):
    @staticmethod
    def get(request):
        r_lform = forms.register_form
        context = {
            'r_lform': r_lform
        }
        print("mmd")
        return render(request, 'regster.html', context)

    def post(self, request):
        register_form = forms.register_form(request.POST)
        if register_form.is_valid():
            user_name = register_form.cleaned_data['username']
            email = register_form.cleaned_data['email']
            user_password = register_form.cleaned_data['password']
            email_exists = User.objects.filter(email__iexact=email).exists()

            if email_exists:
                register_form.add_error('email', 'Email already exists')
                messages.error(request, 'Email already exists')
                return render(request, 'regster.html', {'r_lform': register_form})
            elif User.objects.filter(username__iexact=user_name).exists():
                register_form.add_error('username', 'Username already exists')
                messages.error(request, 'Username already exists')
                return render(request, 'regster.html', {'r_lform': register_form})

            else:
                def rand_num():
                    random_number = generate_random_number()
                    num_exists = User.objects.filter(chat_id=random_number).exists()
                    if num_exists:
                        rand_num()
                    else:
                        return random_number

                rand = rand_num()
                now_user = User(email=email, username=user_name, chat_id=rand)
                now_user.set_password(user_password)
                now_user.save()
                return HttpResponseRedirect(reverse('login'))

        else:
            messages.error(request, 'Invalid input, please try again.')
            return render(request, 'regster.html', {'r_lform': register_form})


class login_indexview(View):
    def get(self, request):
        login_fr = forms.login_form
        context = {
            'login_fr': forms.login_form
        }
        return render(request, 'login.html', context)

    def post(self, request: HttpRequest):
        login_form = forms.login_form(request.POST)
        if login_form.is_valid():
            username = login_form.cleaned_data.get('username')
            user_pass = login_form.cleaned_data.get('password')
            user: User = User.objects.filter(username=username).first()
            if user is not None:
                is_password_correct = user.check_password(user_pass)
                if is_password_correct:
                    login(request, user)
                    return redirect(reverse('index'))
                else:
                    login_form.add_error('password', 'کاربری با مشخصات وارد شده یافت نشد')
                    messages.error(request, 'کاربری با مشخصات وارد شده یافت نشد')
                    return render(request, 'login.html', {'login_fr': login_form})

            else:
                login_form.add_error('username', 'کاربری با مشخصات وارد شده یافت نشد')
                messages.error(request, 'کاربری با مشخصات وارد شده یافت نشد')
                return render(request, 'login.html', {'login_fr': login_form})
        context = {
            'login_form': login_form
        }

        return render(request, 'login.html', context)
