from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    user_role = models.CharField(max_length=50,verbose_name='نقش کاربری')
    chat_id = models.IntegerField( verbose_name='چت آیدی')
    class meta:
        verbose_name ='کاربر'

    def __str__(self):
        return self.get_full_name()